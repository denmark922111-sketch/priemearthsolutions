// PrimeEarth Solutions — lightweight progressive enhancement

// Smooth accordion interaction. Falls back to native <details> when animation is reduced.
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

document.querySelectorAll('details').forEach(details => {
  const summary = details.querySelector(':scope > summary');
  const body = details.querySelector(':scope > div');
  if(!summary || !body || reduceMotion) return;

  summary.addEventListener('click', (e) => {
    e.preventDefault();
    if(details.dataset.animating) return;
    details.open ? closeAcc(details, body) : openAcc(details, body);
  });
});

function openAcc(details, body){
  details.dataset.animating = 'true';
  details.open = true;
  const target = body.scrollHeight;
  body.style.height = '0px';
  body.style.overflow = 'hidden';
  requestAnimationFrame(() => {
    body.style.transition = 'height 0.35s var(--ease)';
    body.style.height = target + 'px';
  });
  body.addEventListener('transitionend', function done(){
    body.style.height = '';
    body.style.overflow = '';
    body.style.transition = '';
    delete details.dataset.animating;
    body.removeEventListener('transitionend', done);
  }, { once: true });
}

function closeAcc(details, body){
  details.dataset.animating = 'true';
  const start = body.scrollHeight;
  body.style.height = start + 'px';
  body.style.overflow = 'hidden';
  requestAnimationFrame(() => {
    body.style.transition = 'height 0.3s var(--ease)';
    body.style.height = '0px';
  });
  body.addEventListener('transitionend', function done(){
    details.open = false;
    body.style.height = '';
    body.style.overflow = '';
    body.style.transition = '';
    delete details.dataset.animating;
    body.removeEventListener('transitionend', done);
  }, { once: true });
}

// Lazy image fade-in.
document.querySelectorAll('img[loading="lazy"]').forEach(img => {
  if(img.complete) img.classList.add('img-loaded');
  else img.addEventListener('load', () => img.classList.add('img-loaded'), { once: true });
  img.addEventListener('error', () => img.classList.add('img-loaded'), { once: true });
});

// Mobile navigation with Escape support and ARIA state.
function toggleMobileMenu(){
  const m = document.getElementById('mobileMenu');
  const btn = document.querySelector('.nav-toggle');
  if(!m) return;
  const open = !m.classList.contains('open');
  m.classList.toggle('open', open);
  if(btn){
    btn.setAttribute('aria-expanded', String(open));
    btn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  }
  document.body.classList.toggle('menu-open', open);
}
window.toggleMobileMenu = toggleMobileMenu;

document.addEventListener('keydown', e => {
  if(e.key === 'Escape'){
    const m=document.getElementById('mobileMenu');
    if(m && m.classList.contains('open')) toggleMobileMenu();
  }
});

document.querySelectorAll('#mobileMenu a').forEach(a => a.addEventListener('click', () => {
  const m=document.getElementById('mobileMenu');
  if(m && m.classList.contains('open')) toggleMobileMenu();
}));

// Navigation state.
const navEl = document.getElementById('nav');
if(navEl){
  const updateNav = () => navEl.classList.toggle('solid', window.scrollY > 20 || document.body.dataset.page !== 'home');
  updateNav();
  window.addEventListener('scroll', updateNav, { passive:true });
}

// Reveal on scroll; avoid creating an observer when reduced motion is requested.
if(!reduceMotion && 'IntersectionObserver' in window){
  const obs = new IntersectionObserver(entries => {
    entries.forEach(x => {
      if(x.isIntersecting){ x.target.classList.add('on'); obs.unobserve(x.target); }
    });
  }, { threshold:0.07, rootMargin:'0px 0px -30px 0px' });
  document.querySelectorAll('.rv,.rvl,.rvr').forEach(el => {
    const siblings=Array.from(el.parentNode.children).filter(c=>c.classList.contains('rv')||c.classList.contains('rvl')||c.classList.contains('rvr'));
    const idx=siblings.indexOf(el);
    el.style.transitionDelay=(idx*0.08)+'s';
    obs.observe(el);
  });
} else {
  document.querySelectorAll('.rv,.rvl,.rvr').forEach(el => el.classList.add('on'));
}

// Decorative canvas; do not run it for reduced-motion users.
const C=document.getElementById('cnv');
if(C && !reduceMotion){
  const ctx=C.getContext('2d');
  let W,H,pts=[];
  const dpr=Math.min(window.devicePixelRatio||1,2);
  function rsz(){
    W=window.innerWidth; H=Math.max(window.innerHeight,500);
    C.width=Math.floor(W*dpr); C.height=Math.floor(H*dpr); C.style.width=W+'px'; C.style.height=H+'px';
    ctx.setTransform(dpr,0,0,dpr,0,0);
  }
  rsz(); window.addEventListener('resize',rsz,{passive:true});
  function Pt(){this.x=Math.random()*W;this.y=Math.random()*H;this.r=Math.random()*1.4+0.3;this.vx=(Math.random()-0.5)*0.28;this.vy=(Math.random()-0.5)*0.28;this.a=Math.random()*0.35+0.08}
  Pt.prototype.u=function(){this.x+=this.vx;this.y+=this.vy;if(this.x<0)this.x=W;if(this.x>W)this.x=0;if(this.y<0)this.y=H;if(this.y>H)this.y=0};
  Pt.prototype.d=function(){ctx.beginPath();ctx.arc(this.x,this.y,this.r,0,Math.PI*2);ctx.fillStyle=`rgba(200,146,42,${this.a})`;ctx.fill()};
  const count = window.innerWidth<768 ? 28 : 52;
  for(let i=0;i<count;i++)pts.push(new Pt());
  let frame=0;
  function draw(){
    frame=requestAnimationFrame(draw);
    ctx.clearRect(0,0,W,H);
    for(let i=0;i<pts.length;i++){
      pts[i].u();pts[i].d();
      for(let j=i+1;j<pts.length;j++){
        const dx=pts[i].x-pts[j].x,dy=pts[i].y-pts[j].y;
        const d=Math.sqrt(dx*dx+dy*dy);
        if(d<130){ctx.beginPath();ctx.moveTo(pts[i].x,pts[i].y);ctx.lineTo(pts[j].x,pts[j].y);ctx.strokeStyle=`rgba(200,146,42,${0.05*(1-d/130)})`;ctx.lineWidth=0.5;ctx.stroke()}
      }
    }
  }
  draw();
  window.addEventListener('pagehide',()=>cancelAnimationFrame(frame),{once:true});
}

// Contact form — Web3Forms submission with client-side validation.
async function handleForm(e){
  e.preventDefault();
  const form=e.target;
  const btn=document.getElementById('cfSubmitBtn');
  const okMsg=document.getElementById('cf-ok');
  const errMsg=document.getElementById('cf-err');
  if(!form || !btn || !okMsg || !errMsg) return;

  okMsg.classList.remove('show'); errMsg.classList.remove('show');
  const accessKey=form.querySelector('[name="access_key"]')?.value || '';
  if(!accessKey || accessKey === 'YOUR_WEB3FORMS_ACCESS_KEY'){
    errMsg.querySelector('span').textContent='Form is not yet connected — please call us directly at +91 98336 23880.';
    errMsg.classList.add('show'); return;
  }

  const phone=form.querySelector('[name="phone"]')?.value.trim() || '';
  if(phone.replace(/\D/g,'').length < 8){
    errMsg.querySelector('span').textContent='Please enter a valid phone number, or call +91 98336 23880.';
    errMsg.classList.add('show'); return;
  }

  const originalText=btn.textContent;
  btn.disabled=true;
  btn.innerHTML='<span class="btn-spin"></span>Sending…';
  try{
    const res=await fetch('https://api.web3forms.com/submit',{
      method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},
      body:JSON.stringify(Object.fromEntries(new FormData(form)))
    });
    const data=await res.json();
    if(!res.ok || !data.success) throw new Error(data.message || 'Submission failed');
    okMsg.classList.add('show'); form.reset();
  }catch(err){
    errMsg.querySelector('span').textContent='We could not send the enquiry right now. Please call +91 98336 23880 or message us on WhatsApp.';
    errMsg.classList.add('show');
  }finally{
    btn.disabled=false; btn.textContent=originalText;
    window.setTimeout(()=>{okMsg.classList.remove('show');errMsg.classList.remove('show');},8000);
  }
}
window.handleForm=handleForm;
