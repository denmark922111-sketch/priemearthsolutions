# PrimeEarth Solutions — Final Deployment Notes

## Deployment package

This is the QA-checked static site package for `primeearthsolutions.in`.

### Preserve these root files

- `_redirects`
- `_headers`
- `robots.txt`
- `sitemap.xml`
- `404.html`
- `site.webmanifest`
- `favicon.svg`
- `styles.css`
- `script.js`
- all `*.html` pages
- `images/`

## Cloudflare Pages routing

Cloudflare Pages normally serves matching HTML pages at extensionless routes. The package therefore uses explicit legacy redirects such as:

`/services.html` → `/services`

Do not add a second set of `200` proxy rules unless a Cloudflare Pages routing test demonstrates they are required.

Keep any existing Cloudflare dashboard rule that redirects `www.primeearthsolutions.in` to `primeearthsolutions.in`.

## Post-deployment smoke test

Open:

- `https://primeearthsolutions.in/`
- `/services`
- `/standards`
- `/industries`
- `/resources`
- `/faq`
- `/contact`
- `/calculators`

Then verify one legacy URL, for example:

`https://primeearthsolutions.in/services.html`

It should return a 301 to `/services`.

Also verify:

- `/sitemap.xml` loads and contains the clean canonical URLs.
- `/robots.txt` references `/sitemap.xml`.
- The contact form accepts valid data and displays the success message only after Web3Forms confirms success.
- WhatsApp and phone links open correctly.
- Mobile navigation opens/closes correctly.

## Search Console cleanup

Keep the healthy `/sitemap.xml` submission and remove the historical erroneous submissions from the Search Console UI when convenient.
